#include "node.h"
#include <iostream>
using namespace std;
template <class T>
class LinkQueue
{
protected:
    Node<T> *forward; //指向队列中排在最前面的元素
    Node<T> *behind;  //指向队列中排在最后面的元素
    void Init();

public:
    LinkQueue();
    ~LinkQueue();
    LinkQueue(LinkQueue<T> &copy);
    LinkQueue<T> &operator=(const LinkQueue<T> &copy);
    int Length() const;
    void Show() const; //从前到后打印元素
    void Clear();
    bool Empty() const;
    bool Out(T &e);
    bool In(const T &e);
    bool Thefirst(T &e);
};

template <class T>
void LinkQueue<T>::Init()
{
    forward = new Node<T>;
    behind = forward;
}

template <class T>
void LinkQueue<T>::Show() const
{
    for (Node<T> *tmpPtr = forward->next; tmpPtr != NULL; tmpPtr = tmpPtr->next)
    {
        cout << tmpPtr->data << ' ';
    }
}

template <class T>
LinkQueue<T>::LinkQueue()
{
    Init();
}

template <class T>
int LinkQueue<T>::Length() const
{
    Node<T> *tmpPtr = forward;
    int count = 0;
    while (tmpPtr != behind)
    {
        count++;
        tmpPtr = tmpPtr->next;
    }
    return count;
}

template <class T>
void LinkQueue<T>::Clear()
{
    T e;
    while (Length() > 0)
    {
        Out(e);
    }
}

template <class T>
LinkQueue<T>::~LinkQueue()
{
    Clear();
    delete forward;
    behind = NULL;
}

template <class T>
LinkQueue<T>::LinkQueue(LinkQueue<T> &copy)
{
    Init();
    for (Node<T> *tmpPtr = copy.forward->next; tmpPtr != NULL; tmpPtr = tmpPtr->next)
    {
        this->In(tmpPtr->data);
    }
}

template <class T>
LinkQueue<T> &LinkQueue<T>::operator=(const LinkQueue<T> &copy)
{
    Clear();
    for (Node<T> *tmpPtr = copy.forward->next; tmpPtr != NULL; tmpPtr = tmpPtr->next)
    {
        this->In(tmpPtr->data);
    }
    return *this;
}

template <class T>
bool LinkQueue<T>::Empty() const
{
    return Length() == 0;
}

template <class T>
bool LinkQueue<T>::Thefirst(T &e)
{
    if (forward == behind)
        return false;
    else
    {
        e = forward->next->data;
        return true;
    }
}

template <class T>
bool LinkQueue<T>::In(const T &e)
{
    Node<T> *newPtr = new Node<T>(e, NULL);
    behind->next = newPtr;
    behind = newPtr;
    return true;
}

template <class T>
bool LinkQueue<T>::Out(T &e)
{
    if (Length() == 0)
        return false;
    else
    {
        Node<T> *tmpPtr = forward->next;
        e = tmpPtr->data;
        if (behind == tmpPtr)
            behind = forward;
        forward->next = tmpPtr->next;
        delete tmpPtr;
    }
    return true;
}
