#include "Graph.h"
using namespace std;

int main()
{
  char str[] = "ABCDEF";
  UndirGraph<char> Map(str, 6);
  Map.InsertEdge(1, 2);
  Map.InsertEdge(1, 5);
  Map.InsertEdge(2, 5);
  Map.InsertEdge(2, 6);
  Map.InsertEdge(3, 6);
  Map.InsertEdge(3, 4);
  Map.InsertEdge(4, 6);
  cout << "广度优先搜索：";
  Map.BFS(2);
  cout << endl;
  cout << "深度优先搜索：";
  Map.DFS(2);
}