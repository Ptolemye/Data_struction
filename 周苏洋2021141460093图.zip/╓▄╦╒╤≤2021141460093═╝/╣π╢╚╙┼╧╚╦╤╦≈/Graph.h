#include <iostream>
#include <algorithm>
#include "LinkQueue.h"
using namespace std;

template <class T>
struct node
{
  int number;
  node<T> *next;
  node();
  node(int a, node<T> *next = NULL);
};

template <class T>
node<T>::node()
{
  next = NULL;
}

template <class T>
node<T>::node(int a, node<T> *next)
{
  number = a;
  this->next = next;
}

template <class T>
struct Head_Node
{
  T data;
  node<T> *firstVex;
  Head_Node();
  Head_Node(T data, node<T> *firstVex = NULL);
};

template <class T>
Head_Node<T>::Head_Node()
{
  firstVex = NULL;
}

template <class T>
Head_Node<T>::Head_Node(T data, node<T> *firstVex)
{
  this->data = data;
  this->firstVex = firstVex;
}

template <class T>
class UndirGraph
{
protected:
  int vexNum;
  Head_Node<T> *vextable;
  int *flag;
  void DFS_aid(int i);
  void BFS_aid(int i);

public:
  UndirGraph();
  UndirGraph(T datalist[], int vexNum);
  UndirGraph(int vexNum);
  ~UndirGraph();
  int GetELem(int t);
  void SetElem(int t, const T data);
  int VexNum();
  int EdgeNum();
  void InsertEdge(int v1, int v2);
  void DeleteEdge(int v1, int v2);
  bool JudgeEdge(int v1, int v2);
  void BFS(int i);
  void DFS(int i);
  void Show()
  {
    for (int i = 1; i <= vexNum; i++)
      cout << vextable[i].data;
  }
};

template <class T>
UndirGraph<T>::UndirGraph()
{
  vextable = NULL;
  flag = NULL;
}

template <class T>
UndirGraph<T>::UndirGraph(int vexNum)
{
  this->vexNum = vexNum;
  vextable = new Head_Node<T>[vexNum + 1];
  flag = new int[vexNum + 1];
  fill(flag, flag + vexNum + 1, 0);
}

template <class T>
UndirGraph<T>::UndirGraph(T datalist[], int vexNum)
{
  this->vexNum = vexNum;
  vextable = new Head_Node<T>[vexNum + 1];
  for (int i = 0; i < vexNum; i++)
  {
    vextable[i + 1].data = datalist[i];
  }
  flag = new int[vexNum + 1];
  fill(flag, flag + vexNum + 1, 0);
}

template <class T>
UndirGraph<T>::~UndirGraph()
{
  for (int i = 1; i <= vexNum; i++)
  {
    while (vextable[i].firstVex != NULL)
    {
      DeleteEdge(i, vextable[i].firstVex->number);
    }
  }
  delete[] vextable;
}

template <class T>
void UndirGraph<T>::SetElem(int t, const T data)
{
  vextable[t].data = data;
}

template <class T>
int UndirGraph<T>::GetELem(int t)
{
  return vextable[t].data;
}

template <class T>
int UndirGraph<T>::VexNum()
{
  return vexNum;
}

template <class T>
bool UndirGraph<T>::JudgeEdge(int v1, int v2)
{
  node<T> *tempPtr = vextable[v1].firstVex;
  while (tempPtr != NULL)
  {
    if (tempPtr->number == v2)
      return true;
    else
    {
      tempPtr = tempPtr->next;
    }
  }
  return false;
}

template <class T>
void UndirGraph<T>::InsertEdge(int v1, int v2)
{
  if (JudgeEdge(v1, v2))
    return;
  else
  {
    node<T> *tempPtr1 = new node<T>(v2, vextable[v1].firstVex);
    vextable[v1].firstVex = tempPtr1;
    node<T> *tempPtr2 = new node<T>(v1, vextable[v2].firstVex);
    vextable[v2].firstVex = tempPtr2;
  }
}

template <class T>
void UndirGraph<T>::DeleteEdge(int v1, int v2)
{
  if (!JudgeEdge(v1, v2))
    return;
  if (vextable[v1].firstVex->number == v2)
  {
    node<T> *tempPtr = vextable[v1].firstVex;
    vextable[v1].firstVex = vextable[v1].firstVex->next;
    delete tempPtr;
  }
  else
  {
    node<T> *tempPtr = vextable[v1].firstVex;
    while (tempPtr->next->number != v2)
      tempPtr = tempPtr->next;
    node<T> *t = tempPtr->next;
    tempPtr->next = tempPtr->next->next;
    delete t;
  }
  if (vextable[v2].firstVex->number == v1)
  {
    node<T> *tempPtr = vextable[v2].firstVex;
    vextable[v2].firstVex = vextable[v2].firstVex->next;
    delete tempPtr;
  }
  else
  {
    node<T> *tempPtr = vextable[v2].firstVex;
    while (tempPtr->next->number != v1)
      tempPtr = tempPtr->next;
    node<T> *t = tempPtr->next;
    tempPtr->next = tempPtr->next->next;
    delete t;
  }
}

template <class T>
int UndirGraph<T>::EdgeNum()
{
  int num = 0;
  for (int i = 1; i <= vexNum; i++)
  {
    node<T> *tempPtr = vextable[i].firstVex;
    while (tempPtr != NULL)
    {
      num++;
      tempPtr = tempPtr->next;
    }
  }
  return num / 2;
}

template <class T>
void UndirGraph<T>::DFS_aid(int i)
{
  flag[i] = 1;
  cout << vextable[i].data;
  node<T> *t = vextable[i].firstVex;
  while (t != NULL)
  {
    while (flag[t->number] != 0)
    {
      t = t->next;
      if (t == NULL)
        return;
    }
    DFS_aid(t->number);
    t = t->next;
  }
}

template <class T>
void UndirGraph<T>::DFS(int i)
{
  DFS_aid(i);
  fill(flag, flag + vexNum + 1, 0);
}

template <class T>
void UndirGraph<T>::BFS_aid(int i)
{
  LinkQueue<int> lq;
  lq.In(i);
  while (!lq.Empty())
  {
    int t;
    lq.Out(t);
    if (flag[t] == 0)
    {
      cout << vextable[t].data;
      flag[t] = 1;
    }
    node<T> *tempPtr = vextable[t].firstVex;
    while (tempPtr != NULL)
    {
      if (flag[tempPtr->number] == 0)
      {
        lq.In(tempPtr->number);
        cout << vextable[tempPtr->number].data;
        flag[tempPtr->number] = 1;
      }
      tempPtr = tempPtr->next;
    }
  }
}

template <class T>
void UndirGraph<T>::BFS(int i)
{
  BFS_aid(i);
  fill(flag, flag + vexNum + 1, 0);
}