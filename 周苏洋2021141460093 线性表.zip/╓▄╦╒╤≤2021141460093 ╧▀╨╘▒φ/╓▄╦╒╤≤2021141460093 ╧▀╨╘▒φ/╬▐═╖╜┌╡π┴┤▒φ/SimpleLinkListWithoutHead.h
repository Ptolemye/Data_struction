#include "node.h"
using namespace std;
template <class T>
class SimpleLinkListWithoutHead
{
private:
    Node<T> *firstPtr;
    Node<T> *GetPtr(int position);
    void Init();

public:
    SimpleLinkListWithoutHead();
    virtual ~SimpleLinkListWithoutHead();
    int Length();
    void Clear();
    bool isEmpty();
    bool GetElem(T &e, int position);
    bool SetElem(T &e, int position);
    bool Insert(T &e, int position);
    bool Delete(T &e, int position);
    void Traverse(void (*visit)(const T &)) const;
    SimpleLinkListWithoutHead(const SimpleLinkListWithoutHead<T> &copy);
    SimpleLinkListWithoutHead<T> &operator=(const SimpleLinkListWithoutHead<T> &copy);
};

template <class T>
Node<T> *SimpleLinkListWithoutHead<T>::GetPtr(int position)
{
    Node<T> *tmpPtr = firstPtr;
    int count == 0;
    if (position > Length())
        return NULL;
    for (; tmpPtr != NULL; tmpPtr = tmpPtr->next)
    {
        count++;
        if (count == position)
            return tmpPtr;
    }
    return NULL;
}

template <class T>
void SimpleLinkListWithoutHead<T>::Init()
{
    firstPtr = NULL; //无头结点，初始化时首位指针指向NULL。
}

template <class T>
SimpleLinkListWithoutHead<T>::SimpleLinkListWithoutHead()
{
    Init();
}

template <class T>
SimpleLinkListWithoutHead<T>::~SimpleLinkListWithoutHead()
{
    Clear();
}

template <class T>
int SimpleLinkListWithoutHead<T>::Length()
{
    if (firstPtr == NULL)
        return 0;
    int count = 1;
    Node<T> *tmpPtr = firstPtr->next;
    while (tmpPtr != NULL)
    {
        count++;
        tmpPtr = tmpPtr->next;
    }
    return count;
}

template <class T>
bool SimpleLinkListWithoutHead<T>::isEmpty()
{
    return Length() == 0;
}

template <class T>
void SimpleLinkListWithoutHead<T>::Clear()
{
    T e;
    while (Length() > 0)
    {
        Delete(e, Length());
    }
}

template <class T>
bool SimpleLinkListWithoutHead<T>::GetElem(T &e, int position)
{
    if (position > Length() || position <= 0)
        return false;
    Node<T> *tmpPtr = GetPtr(position);
    e = tmpPtr->data;
    return true;
}

template <class T>
bool SimpleLinkListWithoutHead<T>::SetElem(T &e, int position)
{
    if (position > Length() || position <= 0)
        return false;
    Node<T> *tmpPtr = GetPtr(position);
    tmpPtr->data = e;
}

template <class T>
bool SimpleLinkListWithoutHead<T>::Delete(T &e, int position)
{
    if (position > Length() || position <= 0)
        return false;
    else if (position == 1) //删除首节点
    {
        Node<T> *nextPtr = firstPtr->next;
        Node<T> *oldPtr = firstPtr;
        firstPtr = nextPtr;
        delete oldPtr;
        return true;
    }
    else
    {
        Node<T> *tmpPtr = GetPtr(position - 1);
        Node<T> *oldPtr = GetPtr(position);
        e = oldPtr->data;
        tmpPtr->next = oldPtr->next;
        delete oldPtr;
        return true;
    }
}

template <class T>
bool SimpleLinkListWithoutHead<T>::Insert(T &e, int position)
{
    if (position > Length() + 1 || position <= 0)
        return false;
    else if (position == 1) //添加首节点
    {
        Node<T> *nextPtr = firstPtr;
        Node<T> *newPtr = Node<T>(e, nextPtr);
        firstPtr = newPtr;
        return true;
    }
    else
    {
        Node<T> *tmpPtr = GetPtr(position - 1);
        Node<T> *nextPtr = tmpPtr->next;
        Node<T> *newPtr = new Node<T>(e, nextPtr);
        tmpPtr->next = newPtr;
        return true;
    }
}

template <class T>
SimpleLinkListWithoutHead<T>::SimpleLinkListWithoutHead(const SimpleLinkListWithoutHead<T> &copy)
{
    Init();
    T e;
    for (int i = 1; i <= copy.Length(); i++)
    {
        copy.GetElem(e, i);
        this->Insert(e, i);
    }
}

template <class T>
SimpleLinkListWithoutHead<T> &SimpleLinkListWithoutHead<T>::operator=(const SimpleLinkListWithoutHead<T> &copy)
{
    Clear();
    for (int i = 1; i <= copy.Length(); i++)
    {
        T e;
        copy.GetElem(e, i);
        this->Insert(e, i);
    }
    return *this;
}
