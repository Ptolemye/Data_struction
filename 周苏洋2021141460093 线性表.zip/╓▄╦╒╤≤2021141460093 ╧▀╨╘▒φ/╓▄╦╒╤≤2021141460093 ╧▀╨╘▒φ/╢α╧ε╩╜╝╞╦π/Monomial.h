#include <iostream>
struct Monomial //单项式，多项式由单项式组成，
{
    //数据成员
    double coef;
    int expn;
    Monomial();
    Monomial(double coef, int expn);
    Monomial &operator=(const Monomial &copy);
};

Monomial::Monomial()
{
    expn = -1;
}

Monomial::Monomial(double coef, int expn)
{
    this->coef = coef;
    this->expn = expn;
} //带参初始化

Monomial &Monomial::operator=(const Monomial &copy)
{
    this->coef = copy.coef;
    this->expn = copy.expn;
    return *this;
}