#include "node.h"
template <class T>
class SimpleLinkList
{
protected:
    Node<T> *head;

public:
    Node<T> *GetPtr(int position) const;
    void Init();
    SimpleLinkList();
    virtual ~SimpleLinkList();
    int Length() const;
    bool isEmpty() const;
    void Clear();
    void Traverse(void (*visit)(const T &e));
    bool GetElem(T &e, int position) const;
    bool SetElem(const T &e, int position);
    bool Delete(T &e, int postion);
    bool Insert(const T &e, int position);
    SimpleLinkList(const SimpleLinkList<T> &copy);
    SimpleLinkList<T> &operator=(const SimpleLinkList<T> &copy);
};

template <class T>
Node<T> *SimpleLinkList<T>::GetPtr(const int position) const
{
    if (position > Length() || position < 0)
        return NULL;
    int count = -1;
    for (Node<T> *tmpPtr = head; tmpPtr != NULL; tmpPtr = tmpPtr->next)
    {
        count++;
        if (count == position)
            return tmpPtr;
    }
    return NULL;
}

template <class T>
void SimpleLinkList<T>::Init()
{
    head = new Node<T>;
}

template <class T>
SimpleLinkList<T>::SimpleLinkList()
{
    Init();
}

template <class T>
SimpleLinkList<T>::~SimpleLinkList()
{
    Clear();
    delete head;
}

template <class T>
int SimpleLinkList<T>::Length() const
{
    int count = 0;
    Node<T> *tmpPtr = head->next;
    for (; tmpPtr != NULL; tmpPtr = tmpPtr->next)
    {
        count++;
    }
    return count;
}

template <class T>
bool SimpleLinkList<T>::isEmpty() const
{
    return Length() == 0;
}

template <class T>
void SimpleLinkList<T>::Clear()
{
    T elem;
    while (Length() > 0)
    {
        Delete(elem, 1);
    }
}
template <class T>
void SimpleLinkList<T>::Traverse(void (*visit)(const T &e))
{
    for (Node<T> *tmpPtr = head->next; tmpPtr != NULL; tmpPtr = tmpPtr->next)
    {
        (*visit)(tmpPtr->data);
    }
}
template <class T>
bool SimpleLinkList<T>::GetElem(T &e, int position) const
{
    if (position > Length() || position <= 0)
        return false;
    else
    {
        Node<T> *tmpPtr = GetPtr(position);
        e = tmpPtr->data;
        return true;
    };
}

template <class T>
bool SimpleLinkList<T>::SetElem(const T &e, int position)
{
    if (position > Length() || position <= 0)
        return false;
    else
    {
        Node<T> *tmpPtr = GetPtr(position);
        tmpPtr->data = e;
        return true;
    }
}

template <class T>
bool SimpleLinkList<T>::Insert(const T &e, int position)
{
    if (position <= 0 || position > Length() + 1)
        return false;
    else
    {
        Node<T> *tmpPtr1 = GetPtr(position - 1);
        Node<T> *newPtr = new Node<T>(e, tmpPtr1->next);
        tmpPtr1->next = newPtr;
        return true;
    }
}

template <class T>
bool SimpleLinkList<T>::Delete(T &e, int position)
{
    if (position <= 0 || position > Length())
        return false;
    else
    {
        Node<T> *tmpPtr = GetPtr(position - 1);
        Node<T> *oldPtr = GetPtr(position);
        tmpPtr->next = tmpPtr->next->next;
        e = oldPtr->data;
        delete oldPtr;
        return true;
    }
}

template <class T>
SimpleLinkList<T>::SimpleLinkList(const SimpleLinkList<T> &copy)
{
    Init();
    T e;
    for (int i = 1; i <= copy.Length(); i++)
    {
        copy.GetElem(e, i);
        Insert(e, i);
    }
}

template <class T>
SimpleLinkList<T> &SimpleLinkList<T>::operator=(const SimpleLinkList<T> &copy)
{
    Clear();
    for (int i = 1; i <= copy.Length(); i++)
    {
        T e;
        copy.GetElem(e, i);
        this->Insert(e, i);
    }
    return *this;
}
