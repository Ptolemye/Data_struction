//检测多项式计算
#include "Polynomial.h"
using namespace std;

int main()
{
    Polynomial la;
    la.Add(2, 3);
    la.Add(3, 4);
    la.Add(5, 4);
    la.Add(3, 3);
    la.Add(-5, 2);
    la.Show(); //化简前展示
    cout << endl;
    la.Simplify();
    la.Show(); //化简后后展示
    cout << endl;
    Polynomial lb;
    lb.Add(1, 4);
    lb.Add(-3, 3);
    lb.Add(0, 5); //系数为0的特殊处理
    lb.Simplify();
    lb.Show();
    cout << endl;
    Polynomial lc = la + lb;
    lc.Show(); //加法
    cout << endl;
    lc = la - lb;
    lc.Show(); //减法
    cout << endl;
    lc = la * lb;
    lc.Show(); //乘法
    //所有功能演示完毕
}
