#include <iostream>
#include "Monomial.h"
#include "SimpleLinkList.h"
#include <math.h>
using namespace std;
class Polynomial
{
protected:
    SimpleLinkList<Monomial> PolyList; //已有链表模板，只需要改变参数T

public:
    Polynomial();
    ~Polynomial();
    int Length(); //判断多项式的项数
    bool isZero();
    void Simplify();
    void SetZero();
    void Show();
    void Insert(const Monomial &e); //插入单项式
    void fun();
    void Add(double a, int b);
    Polynomial &operator=(const Polynomial &copy);
    Polynomial(const Polynomial &copy);
    Polynomial operator+(const Polynomial &p) const;
    Polynomial operator-(const Polynomial &p) const;
    Polynomial operator*(const Polynomial &p) const;
};

Polynomial::Polynomial() {}

Polynomial::Polynomial(const Polynomial &copy)
{
    this->PolyList = copy.PolyList;
}

Polynomial::~Polynomial() {}

int Polynomial::Length()
{
    return PolyList.Length();
}
void Polynomial::fun()
{
    Monomial t;
    PolyList.GetElem(t, 1);
    cout << t.coef;
}
void Polynomial::Simplify()
{
    Polynomial self = *this;
    Polynomial tmpList;
    Monomial e;
    while (self.Length() > 0)
    {
        self.PolyList.GetElem(e, 1);
        Monomial f;
        int res = 0;
        self.PolyList.GetElem(f, 1);
        while (f.expn == e.expn)
        {
            res += f.coef;
            Monomial t;
            self.PolyList.Delete(t, 1);
            if (self.Length() != 0)
                self.PolyList.GetElem(f, 1);
            else
                break;
        }
        tmpList.Add(res, e.expn);
    }
    *this = tmpList;
}
bool Polynomial::isZero()
{
    Simplify();
    return Length() == 0;
}
void Polynomial::SetZero()
{
    PolyList.Clear(); //直接删除所有单项式
}
void Polynomial::Show()
{
    if (Length() == 0)
        cout << "0";
    else
    {
        for (int i = 1; i <= Length(); i++)
        {
            Monomial elem;
            PolyList.GetElem(elem, i);
            if (elem.coef < 0)
            {
                cout << elem.coef << 'x' << "^" << elem.expn;
            }
            else if (elem.coef > 0)
            {
                cout << "+" << elem.coef << 'x' << "^" << elem.expn;
            }
        }
    }
}
void Polynomial::Insert(const Monomial &elem)
{
    if (elem.coef == 0)
    {
        return;
    }
    if (Length() == 0)
    {
        PolyList.Insert(elem, 1);
    }
    else
    {
        Monomial tmp;
        PolyList.GetElem(tmp, Length());
        if (elem.expn > tmp.expn)
        {
            PolyList.Insert(elem, Length() + 1);
        }
        else
        {
            Monomial tmp2;
            for (int i = 1; i <= Length(); i++)
            {
                PolyList.GetElem(tmp2, i);
                if (tmp2.expn >= elem.expn)
                {
                    PolyList.Insert(elem, i);
                    break;
                }
            }
        }
    }
}
void Polynomial::Add(double a, int b) //封装了Insert函数
{
    Monomial tmp(a, b);
    Insert(tmp);
}
Polynomial Polynomial::operator+(const Polynomial &p) const
{
    Polynomial la = *this; //副本1
    Polynomial lb = p;     //副本2
    Polynomial res;        //用于存放答案
    la.Simplify();         //简化la
    lb.Simplify();         //简化lb
    int aPosition, bPosition;
    for (aPosition = 1; aPosition <= la.Length(); aPosition++)
    {
        Monomial tmpElem;
        la.PolyList.GetElem(tmpElem, aPosition);
        res.Insert(tmpElem);
    }
    for (bPosition = 1; bPosition <= lb.Length(); bPosition++)
    {
        Monomial tmpElem;
        lb.PolyList.GetElem(tmpElem, bPosition);
        res.Insert(tmpElem);
    }
    res.Simplify();
    return res;
}

Polynomial &Polynomial::operator=(const Polynomial &copy)
{
    this->PolyList = copy.PolyList;
    return *this;
}

Polynomial Polynomial::operator-(const Polynomial &p) const
{
    Polynomial la = *this; //副本1
    Polynomial lb_1 = p;   //副本2
    Polynomial lb_2;       //用于存放取反的lb
    Polynomial res;        //用于存放答案
    la.Simplify();         //简化la
    lb_1.Simplify();       //简化lb
    int aPosition, bPosition;
    for (int i = 0; i < lb_1.Length(); i++)
    {
        Monomial tmpElem;
        lb_1.PolyList.GetElem(tmpElem, i);
        tmpElem.coef = 0 - tmpElem.coef;
        lb_2.Insert(tmpElem);
    }
    for (aPosition = 1; aPosition <= la.Length(); aPosition++)
    {
        Monomial tmpElem;
        la.PolyList.GetElem(tmpElem, aPosition);
        res.Insert(tmpElem);
    }
    for (bPosition = 1; bPosition <= lb_2.Length(); bPosition++)
    {
        Monomial tmpElem;
        lb_2.PolyList.GetElem(tmpElem, bPosition);
        res.Insert(tmpElem);
    }
    res.Simplify();
    return res;
}

Polynomial Polynomial::operator*(const Polynomial &p) const
{
    Polynomial la = *this; //副本1
    Polynomial lb = p;     //副本2
    Polynomial res;
    int aPosition, bPosition;
    la.Simplify();
    lb.Simplify();
    for (aPosition = 1; aPosition <= la.Length(); aPosition++)
    {
        for (bPosition = 1; bPosition <= lb.Length(); bPosition++)
        {
            Monomial tmpElema;
            la.PolyList.GetElem(tmpElema, aPosition);
            Monomial tmpElemb;
            lb.PolyList.GetElem(tmpElemb, bPosition);
            double a = tmpElema.coef * tmpElemb.coef;
            int b = tmpElema.expn + tmpElemb.expn;
            Monomial newMon(a, b);
            res.Insert(newMon);
        }
    }
    res.Simplify();
    return res;
}
