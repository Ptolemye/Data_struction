#include <iostream>
using namespace std;

template <class T>
class Node_cross
{
public:
    T elem;
    int x, y;
    Node_cross<T> *right, *down;
    Node_cross();
    Node_cross(T elem, int x, int y, Node_cross<T> *right = NULL, Node_cross<T> *down = NULL);
};

template <class T>
Node_cross<T>::Node_cross()
{
    right = NULL;
    down = NULL;
}

template <class T>
Node_cross<T>::Node_cross(T e, int a, int b, Node_cross<T> *c, Node_cross<T> *d)
{
    this->elem = e;
    this->x = a;
    this->y = b;
    this->down = d;
    this->right = c;
}

template <class T>
class SparseMatrix_Cross
{
protected:
    Node_cross<T> **first_right;
    Node_cross<T> **first_down;
    int row, col, num;

public:
    SparseMatrix_Cross();
    SparseMatrix_Cross(int row, int col);
    ~SparseMatrix_Cross();
    SparseMatrix_Cross(const SparseMatrix_Cross<T> &copy);
    SparseMatrix_Cross<T> &operator=(const SparseMatrix_Cross<T> &copy);
    void Clear();
    bool Insert(Node_cross<T> &temp_elem);
    bool Insert(int x, int y, T e);
    int Number() const;
    int Col() const;
    int Row() const;
    void Show() const;
    T GetElem(int x, int y) const;
    void SetElem(int x, int y, const T &e);
};

template <class T>
SparseMatrix_Cross<T>::SparseMatrix_Cross()
{
    first_right = NULL;
    first_down = NULL;
    num = 0;
}

template <class T>
SparseMatrix_Cross<T>::SparseMatrix_Cross(int row, int col)
{
    this->row = row;
    this->col = col;
    first_down = new Node_cross<T> *[col + 1];
    first_right = new Node_cross<T> *[row + 1];
    for (int i = 0; i <= this->col; i++)
    {
        first_down[i] = NULL;
    }
    for (int i = 0; i <= this->row; i++)
    {
        first_right[i] = NULL;
    }
    num = 0;
}

template <class T>
SparseMatrix_Cross<T>::~SparseMatrix_Cross()
{
    Clear();
}

template <class T>
void SparseMatrix_Cross<T>::Show() const
{
    for (int i = 1; i <= row; i++)
    {
        for (int j = 1; j <= col; j++)
        {
            cout << this->GetElem(i, j) << ' ';
            if (j == col)
                cout << endl;
        }
    }
    cout << endl;
}
template <class T>
void SparseMatrix_Cross<T>::Clear()
{
    for (int i = 1; i <= row; i++)
    {
        while (first_right[i] != NULL)
        {
            Node_cross<T> *temp = first_right[i];
            if (temp->right == NULL)
            {
                delete temp;
                first_right[i] = NULL;
            }
            else
            {
                while (temp->right->right != NULL)
                {
                    temp = temp->right;
                }
                delete temp->right;
                temp->right = NULL;
            }
        }
    }
    for (int i = 1; i <= col; i++)
    {
        first_down[i] = NULL;
    }
    num = 0;
}

template <class T>
SparseMatrix_Cross<T>::SparseMatrix_Cross(const SparseMatrix_Cross<T> &copy)
{
}

template <class T>
bool SparseMatrix_Cross<T>::Insert(Node_cross<T> &temp_elem)
{
    int l_x = temp_elem.x;
    int l_y = temp_elem.y;
    Node_cross<T> *new_elem = new Node_cross<T>(temp_elem.elem, l_x, l_y);
    //先做行处理
    if (first_right[l_x] == NULL)
    {
        first_right[l_x] = new_elem;
    }
    else
    {
        Node_cross<T> *left_node = first_right[l_x];
        Node_cross<T> *right_node = left_node->right;
        if (left_node->y > new_elem->y)
        {
            //头插入
            first_right[l_x] = new_elem;
            new_elem->right = left_node;
        }
        else
        {
            for (; right_node != NULL;)
            {
                if (right_node->y > new_elem->y && left_node->y < new_elem->y)
                    break;
                else
                {
                    left_node = right_node;
                    right_node = left_node->right;
                }
            }
            if (right_node == NULL)
            {
                left_node->right = new_elem;
                //尾插入
            }
            else
            {
                left_node->right = new_elem;
                new_elem->right = right_node;
            }
        }
    }
    if (first_down[l_y] == NULL)
    {
        first_down[l_y] = new_elem;
    }
    else
    {
        Node_cross<T> *up_node = first_down[l_y];
        Node_cross<T> *down_node = up_node->down;
        if (up_node->x > new_elem->x)
        {
            //头插入
            first_down[l_y] = new_elem;
            new_elem->down = up_node;
        }
        else
        {
            for (; down_node != NULL;)
            {
                if (down_node->x > new_elem->x && up_node->x < new_elem->x)
                    break;
                else
                {
                    up_node = down_node;
                    down_node = up_node->down;
                }
            }
            if (down_node == NULL)
            {
                up_node->down = new_elem;
                //尾插入
            }
            else
            {
                up_node->down = new_elem;
                new_elem->down = down_node;
            }
        }
    }
    num++;
    return true;
}

template <class T>
bool SparseMatrix_Cross<T>::Insert(int x, int y, T e)
{
    Node_cross<T> *temp = new Node_cross<T>(e, x, y);
    Insert(*temp);
    delete temp;
    return true;
}
template <class T>
int SparseMatrix_Cross<T>::Number() const
{
    return num;
}

template <class T>
int SparseMatrix_Cross<T>::Col() const
{
    return col;
}

template <class T>
int SparseMatrix_Cross<T>::Row() const
{
    return row;
}

template <class T>
T SparseMatrix_Cross<T>::GetElem(int x, int y) const
{
    if (x > row || y > col)
        return 0;
    else
    {
        Node_cross<T> *temp = first_right[x];
        while (temp != NULL)
        {
            if (temp->y == y)
            {
                return temp->elem;
            }
            else
            {
                temp = temp->right;
            }
        }
    }
    return 0;
}

template <class T>
void SparseMatrix_Cross<T>::SetElem(int x, int y, const T &e)
{
    if (e == 0)
        return;
    Node_cross<T> *temp = first_right[x];
    while (temp != NULL)
    {
        if (temp->y == y)
        {
            temp->elem = e;
            return;
        }
        else
        {
            temp = temp->right;
        }
    }
    Node_cross<T> t(e, x, y);
    this->Insert(t);
}
