#include <iostream>
#include "SparseMatrix_Cross.h"
using namespace std;
int main()
{
    SparseMatrix_Cross<int> Matrix(5, 5);
    Matrix.Insert(2, 2, 5);
    Matrix.Insert(2, 1, 3);
    cout << Matrix.GetElem(2, 2) << endl;
    cout << Matrix.GetElem(2, 1) << endl;
    Matrix.Show();
    Matrix.SetElem(2, 2, 3);
    Matrix.SetElem(3, 3, 2);
    cout << "更改后为：" << endl;
    Matrix.Show();
}