#include "iostream"

template<class T>
void ShellSort(T list[],const int length)
{
    int gap=length/2;
    while(gap>=1)
    {
        T e;
        for(int i=gap;i<length;i++) {
            e=list[i];
            for(int j=i-gap;j>=0;j-=gap)
            {
                if(e<=list[j])list[j+gap]=list[j];
                else if(e>list[j]){
                    list[j+gap]=e;
                    break;
                }
                if(j-gap<0)
                {
                    list[j]=e;
                }
            }
        }
        gap=gap/2;
    }
}
