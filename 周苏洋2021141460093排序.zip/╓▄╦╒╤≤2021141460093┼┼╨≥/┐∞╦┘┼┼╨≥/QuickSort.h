#include "iostream"
template<class T>
void Swap(T &a,T &b)
{
    T t=a;
    a=b;
    b=t;
}
template<class T>
int PartSort(int start,int end,T list[])
{
    while (start<end)
    {
        while(start<end&&list[end]>=list[start])
        {
            end--;
        }
        Swap(list[start],list[end]);
        while(start<end&&list[end]>=list[start])
        {
            start++;
        }
        Swap(list[start],list[end]);
    }
    return start;
}
template<class T>
void QuickSort(T list[],int start,int end)
{
    if(start<end)
    {
        int t= PartSort(start,end,list);
        QuickSort(list,t+1,end);
        QuickSort(list,start,t-1);
    }
}