#include <iostream>
#include "ShellSort.h"
#include "QuickSort.h"
using namespace std;
int main() {
   int a[]={9,2,5,3,1,4,4,2,1};
    ShellSort(a, sizeof(a)/ sizeof(int));
    for(int i=0;i<sizeof(a)/ sizeof(int);i++)
    {
        cout<<a[i];
    }
    cout<<endl;
    int b[]={9,2,5,3,1,4,4,2,1};
    QuickSort(b,0,sizeof (b)/sizeof (int)-1);
    for(int i=0;i<sizeof(b)/ sizeof(int);i++)
    {
        cout<<b[i];
    }
}
