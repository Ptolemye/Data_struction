#include "AllLine.h"

int main()
{
    AllLine *allLine = new AllLine();
    allLine->createLines();
    char command = 'h';
    std::string outPath;
    std::cout << "Please input outputfile name(eg. file_out.txt):";
    getchar();
    std::getline(std::cin, outPath);
    AllLine::help();
    while (command != 'q')
    {
        bool isOPSuccess = true;
        allLine->meau();
        std::cout << "\n&&";
        std::string str;
        std::getline(std::cin, str);
        command = str[0];
        switch (command)
        {
            case 'b':
                allLine->go(0);
                break;
            case 'c':
            {
                int flag;
                std::cout<<"enter 1(this line) enter 2(alllines)";
                std::cin>>flag;
                getchar();
                std::string changeStr, changedStr;
                std::cout << "What text segment do U want to replace? ";
                std::getline(std::cin, changeStr);
                std::cout << "What new text segment do U want to add in. ";
                std::getline(std::cin, changedStr);
                if(flag==1){
                    isOPSuccess = allLine->change(changeStr, changedStr);
                }
                if(flag==2){
                    isOPSuccess= false;
                    int t=allLine->nownumber();
                    for(int i=0;i<=allLine->linenumber();i++)
                    {
                        allLine->go(i);
                        isOPSuccess|=allLine->change(changeStr, changedStr);
                    }
                    allLine->go(t);
                }
                if (!isOPSuccess)
                    std::cout << "String was not found." << std::endl;
            }
                break;
            case 'd': {
                int t = allLine->nownumber();
                isOPSuccess = allLine->del();
                allLine->go(t);}
                break;
                case 'e':
                allLine->go(allLine->length() - 1);
                break;
            case 'f':
            {
                int flag;
                std::cout<<"enter 1(allline) enter 2(lines below)";
                std::cin>>flag;
                std::cout << "Enter string to search for: ";
                std::string findStr;
                getchar();
                std::getline(std::cin, findStr);
                if(flag==1)
                {
                    for(int i=0;i<allLine->linenumber();i++)
                    {
                        allLine->go(i);
                        if(allLine->find(findStr))break;
                        if(i==allLine->linenumber()-1)std::cout << "String was not found." << std::endl;
                    }
                }
                else if(flag==2)
                {
                    for(int i=allLine->nownumber();i<allLine->linenumber();i++)
                    {
                        allLine->go(i);
                        if(allLine->find(findStr))break;
                        if(i==allLine->linenumber()-1)std::cout << "String was not found." << std::endl;
                    }
                }
            }
                break;
            case 'g':
            {
                int rowToGo;
                std::cout << "Goto what line number? ";
                std::cin >> rowToGo;
                if (std::cin.fail())
                {
                    std::cout << "Input error, reload the command pls" << std::endl;
                    std::cin.clear();
                    std::cin.ignore(2048, '\n');
                    break;
                }
                isOPSuccess = allLine->go(rowToGo);
                getchar();
            }
                break;
            case 'h':
                AllLine::help();
                break;
            case 'i':
            {
                int addLineNum;
                std::string insertStr;
                std::cout << "Insert what line number. ";
                std::cin >> addLineNum;
                if (std::cin.fail())
                {
                    std::cout << "Input error, reload the command pls" << std::endl;
                    std::cin.clear();
                    std::cin.ignore(2048, '\n');
                    break;
                }
                std::cout << "What is the new line to insert? ";
                getchar();
                std::getline(std::cin, insertStr);
                isOPSuccess = allLine->insert(addLineNum, insertStr);
            }
                break;
            case 'l':
                allLine->length(true);
                break;
            case 'n':
                isOPSuccess = allLine->next();
                break;
            case 'p':
                isOPSuccess = allLine->prior();
                break;
            case 'r':
            {
                int t=allLine->linenumber()+1;
                while(t--)
                {
                    allLine->del();
                }
                std::string filePath;
                std::cout << "Input the read path of file: ";
                std::getline(std::cin, filePath);
                isOPSuccess = allLine->read(filePath);
                allLine->go(0);
            }
                break;
            case 's':
            {
                int subLineNum;
                std::cout << " Substitute what line number? ";
                std::cin >> subLineNum;
                if (std::cin.fail())
                {
                    std::cout << "Input error, reload the command pls" << std::endl;
                    std::cin.clear();
                    std::cin.ignore(2048, '\n');
                    break;
                }
                isOPSuccess = allLine->substitute(subLineNum);
            }
                break;
            case 'v':
            {
                int t = allLine->nownumber();
                allLine->view();
                allLine->go(t);
            }
                break;

            case 'w':
            {
                std::string writeStr;
                std::cout << "Input the line U want to write: ";
                std::getline(std::cin, writeStr);
                isOPSuccess = allLine->write(writeStr);
            }
                break;
            case 'q':
                break;
            default:
                std::cout << "command error, reload input command" << std::endl;
                break;
        }
        if (!isOPSuccess)
            std::cout << "Command execution error" << std::endl;
    }
    if (allLine->quit(outPath))
    {
        std::cout << "Quit program success" << std::endl;
    }
    else
    {
        std::cout << "Save data error" << std::endl;
    }
    return 0;
}