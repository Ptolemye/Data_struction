#pragma once
#include "EachLine.h"
#include <string>
#include "fstream"
class AllLine
{
private:
    EachLine *nowLine;   //当前节点
    EachLine *firstLine; //头节点
    EachLine *lastLine;  //尾节点
    int nowLineNum;      //现在所在行数
    int LineNum;         //总行数

public:
    AllLine()
    {
        nowLine = NULL;
        firstLine = NULL;
        lastLine = NULL;
        nowLineNum = -1;
        LineNum = -1;
    };                                 //构造函数
    void setEachLine(std::string str); //设置文本
    std::string getEachLine();         //得到文本
    void createLines();                //创建链表

    bool isEmpty();                      //判断是否为空
    EachLine *indexValue(int findIndex); //通过下标获取该行的值如 EachLine* nowLinePtr = indexValue(1)

    // void begin();         //跳转第0行
    bool go(int rowToGo); //跳转指定行
    // void end();           //跳转尾行
    //三个函数可以考虑合成为一个

    void view(); //观看所有文本
    void meau(); //每次输入指令后的结尾菜单

    // bool表示操作不成功返回false 成功返回true
    bool del();                                                 //删除本行
    bool find(std::string findStr);                             //查找字符串
    bool insert(int addLineNum, std::string insertStr);         //插入一行
    bool next();                                                //下一行
    bool prior();                                               //上一行
    bool substitute(int subLineNum);                            //修改一行
    bool write(std::string writeStr);                           //末尾添加一行
    bool change(std::string changeStr, std::string changedStr); //改变一个字符串为另一个

    int length(bool command = false); //返回总行数且输出该行信息

    static void help(); //帮助菜单

    bool read(std::string fileInPath);  //读取文件 输入文件目录 输出是否读取成功
    bool quit(std::string fileOutPath); //退出时写入数据至输出文件 输入输出文件目录 输出是否输出成功
    int linenumber(){
        return LineNum;
    }
    int nownumber(){
        return nowLineNum;
    };
};

void AllLine::setEachLine(std::string str)
{
    nowLine->eachLine = str;
}

std::string AllLine::getEachLine()
{
    if (!nowLine->eachLine.empty())
        return nowLine->eachLine;
    else
        return "";
}

void AllLine::createLines()
{
    std::cout << "Please input inputfile name(eg. file_in.txt):";
    std::string t;
    std::cin >> t;
    read(t);
    this->go(0);
}

bool AllLine::isEmpty()
{
    if (LineNum == -1)
        return true;
    return false;
}

EachLine* AllLine::indexValue(int findIndex)
{
    go(findIndex);
    return nowLine;
}

bool AllLine::go(int rowToGo)
{
    if (rowToGo > LineNum || rowToGo < 0)
    {
        std::cout << "Warning: No such line"
                  << "\n";
        return false;
    }
    else
    {
        if (rowToGo > nowLineNum)
        {
            int stepToGo = rowToGo - nowLineNum;
            while (stepToGo--)
            {
                nowLine = nowLine->nextLine;
                nowLineNum++;
            }
            return true;
        }
        else
        {
            int stepToGo = nowLineNum - rowToGo;
            while (stepToGo--)
            {
                nowLine = nowLine->priorLine;
                nowLineNum--;
            }
            return true;
        }
    }
}

void AllLine::view()
{
    if (isEmpty())
    {
        return;
    }
    else
    {
        nowLine = firstLine;
        nowLineNum = 0;
        while (nowLine->nextLine != NULL)
        {
            std::cout << getEachLine() << "\n";
            nowLine = nowLine->nextLine;
            nowLineNum++;
        }
        std::cout << getEachLine() << "\n";
    }
}

void AllLine::meau()
{
    if (!isEmpty())
        std::cout << nowLineNum<< " : " << getEachLine() << std::endl;
    else
        std::cout << "File buffer is empty(please use command r to read file to buffer)." << std::endl;
}

bool AllLine::change(std::string changeStr, std::string changedStr)
{
    try
    {
        std::string theStringNow;
        theStringNow = getEachLine();
        theStringNow.replace(theStringNow.find(changeStr),changeStr.length(),changedStr);
        setEachLine(theStringNow);
        return true;
    }
    catch (...)
    {
        return false;
    }
}

bool AllLine::del()
{
    try
    {
        if (LineNum == -1)
            return false;
        if (LineNum == 0)
        {
            nowLine = NULL;
            firstLine = NULL;
            lastLine = NULL;
            nowLineNum = -1;
            LineNum = -1;
        }
        else if (nowLineNum == LineNum)
        {
            LineNum--;
            nowLine = lastLine->priorLine;
            nowLine->nextLine = NULL;
            delete (lastLine);
            lastLine = nowLine;
            nowLineNum--;
        }
        else if (nowLineNum == 0)
        {
            LineNum--;
            firstLine = nowLine->nextLine;
            delete (nowLine);
            nowLine = lastLine;
            nowLineNum = LineNum;
        }
        else
        {
            LineNum--;
            EachLine *delNode = new (EachLine);
            delNode = nowLine;
            nowLine = delNode->priorLine;
            nowLine->nextLine = delNode->nextLine;
            nowLine = delNode->nextLine;
            nowLine->priorLine = delNode->priorLine;
            delete (delNode);
            nowLine = lastLine;
            nowLineNum = LineNum;
        }
        return true;
    }
    catch (...)
    {
        return false;
    }
}

bool AllLine::find(std::string findStr)
{
    try
    {
        std::string s2 = findStr;
        while (nowLineNum <= LineNum)
        {
            std::string s1 = getEachLine();
            int lenth = getEachLine().length();
            std::string flag(lenth, ' ');
            int index = s1.find(s2);
            if (index == std::string::npos)
            {
                if (nowLineNum < LineNum)
                {
                    go(nowLineNum + 1);
                    continue;
                }
                else
                {
                    break;
                }
            }
            else
            {
                for (int i = 0; i < findStr.length(); i++)
                {
                    flag[index++] = '^';
                }
                std::cout << getEachLine() << "\n";
                for (int i = 0; i < lenth; i++)
                    std::cout << flag[i];
                std::cout << "\n";
            }
            return true;
        }
        go(LineNum);
        return false;
    }
    catch (...)
    {
        return false;
    }
}

void AllLine::help()
{
    std::cout << "Valid commands are: b(egin) c(hange) d(el) e(nd) \n f(ind) g(o) h(elp) i(nsert) l(ength) n(ext) p(rior) \nq(uit) r(ead) s(ubstitute) v(iew) w(rite)\n";
}

bool AllLine::insert(int addLineNum, std::string insertStr)
{
    EachLine *t0 = indexValue(addLineNum);
    EachLine *t1 = t0->nextLine;
    t0->nextLine = new EachLine;
    t0->nextLine->eachLine = insertStr;
    t0->nextLine->nextLine = t1;
    t0->nextLine->priorLine = t0;
    t1->priorLine = t0->nextLine;
    LineNum++;
    go(addLineNum + 1);
    return true;
}

int AllLine::length(bool command)
{
    if (command)
        std::cout << "There are " << LineNum + 1 << " lines in the file. Current line lenth is " << nowLine->eachLine.length() << std::endl;
    return LineNum + 1;
}

bool AllLine::next()
{
    try
    {
        if (isEmpty())
        {
            std::cout << "File buffer is empty(please use command r to read file to buffer)."
                      << "\n";
            return false;
        }
        if (nowLineNum == LineNum)
        {
            std::cout << " Warning: at end of buffer"
                      << "\n";
            return false;
        }
        nowLineNum++;
        nowLine = nowLine->nextLine;
    }
    catch (...)
    {
        std::cout << " Warning: can't go to next buffer"
                  << "\n";
        return false;
    }
    return true;
}

bool AllLine::prior()
{
    try
    {
        if (isEmpty())
        {
            std::cout << "File buffer is empty(please use command r to read file to buffer)."
                      << "\n";
            return false;
        }
        if (nowLineNum == 0)
        {
            std::cout << " Warning: at start of buffer"
                      << "\n";
            return false;
        }
        nowLineNum--;
        nowLine = nowLine->priorLine;
    }
    catch (...)
    {
        std::cout << " Warning: can't go to prior buffer"
                  << "\n";
        return false;
    }
    return true;
}

bool AllLine::quit(std::string fileOutPath)
{
    std::ofstream ofs(fileOutPath);
    if(ofs.fail()) return 0;
    EachLine* t=firstLine;
    while(t!=NULL)
    {
        ofs<<t->eachLine<<'\n';
        t=t->nextLine;
    }
    return 1;
}

bool AllLine::read(std::string fileInPath)
{
    std::ifstream fin;
    fin.open(fileInPath);
    if (!fin.is_open())
        return 0;
    char t;
    std::string t0;
    if (isEmpty())
    {
        firstLine = nowLine = lastLine = new EachLine;
        std::getline(fin, t0);
        firstLine->eachLine = t0;
        nowLineNum++;
        LineNum++;
    }
    while (std::getline(fin, t0))
    {
        EachLine *newLine = new EachLine;
        newLine->eachLine = t0;
        newLine->nextLine = NULL;
        newLine->priorLine = lastLine;
        lastLine->nextLine = newLine;
        lastLine = newLine;
        nowLine = newLine;
        LineNum++;
        nowLineNum = LineNum;
    }
    fin.close();
    return 1;
}

bool AllLine::substitute(int subLineNum)
{
    try
    {
        if (!go(subLineNum))
            return false;
        std::string subStr;
        int temp = getchar();
        std::cout << "What text do U want to replace: ";
        std::getline(std::cin, subStr);
        setEachLine(subStr);
        return true;
    }
    catch (...)
    {
        return false;
    }
}

bool AllLine::write(std::string writeStr)
{
    try
    {
        if (isEmpty())
        {
            firstLine = nowLine = lastLine = new EachLine;
            firstLine->eachLine = writeStr;
            firstLine->nextLine = NULL;
            nowLineNum++;
            LineNum++;
            return true;
        }
        LineNum++;
        nowLineNum = LineNum;
        EachLine *newTail = new EachLine;
        newTail->eachLine = writeStr;
        newTail->priorLine = lastLine;
        lastLine->nextLine = newTail;
        newTail->nextLine = NULL;
        lastLine = newTail;
        nowLine = newTail;
        return true;
    }
    catch (...)
    {
        return false;
    }
}
